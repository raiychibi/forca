package br.com.fiap.tds.dao;

/**
 * 
 * @author raiyi
 * @version 1.0
 *
 */

public class ClienteDao {

}
